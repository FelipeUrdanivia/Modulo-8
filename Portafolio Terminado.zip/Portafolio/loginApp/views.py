from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required, user_passes_test
from .forms import RegistroForm
from django.contrib import messages

def custom_user_check(user):
    return user.is_superuser

@user_passes_test(custom_user_check)
def vista_super(request):
    return render(request, 'loginApp/superusuario.html')
    
def vista_normal(request):
        # Código para el usuario normal
    return render(request, 'loginApp/usuario_normal.html')

def registro(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('para_logueado')
    else:
        form = RegistroForm()
    return render(request, 'loginApp/registro.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('para_logueado')
    else:
        form = AuthenticationForm()
    return render(request, 'loginApp/login.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    messages.info(request, '¡Has cerrado sesión exitosamente!')
    return redirect('homelogin')

@login_required
def para_logueado(request):
    return render(request, 'loginApp/para_logueado.html', {'usuario': request.user})

def homelogin(request):
        # Código para el usuario normal
    return render(request, 'loginApp/homelogin.html')