# forms.py
from django import forms
from .models import Producto

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['nombre', 'precio', 'cantidad']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'border border-blue-300 p-2 rounded w-full'}),
            'precio': forms.NumberInput(attrs={'class': 'border border-blue-300 p-2 rounded w-full'}),
            'cantidad': forms.NumberInput(attrs={'class': 'border border-blue-300 p-2 rounded w-full'}),
        }
