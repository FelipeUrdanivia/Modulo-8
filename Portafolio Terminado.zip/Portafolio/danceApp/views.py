from django.shortcuts import render

def danceApp(request):
    return render(request, 'danceApp/dance.html')