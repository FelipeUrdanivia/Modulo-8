from django.urls import path
from . import views

urlpatterns = [
    path('dance/', views.danceApp, name='danceApp'),
]