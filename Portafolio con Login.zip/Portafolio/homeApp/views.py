from django.shortcuts import render
from django.core.mail import send_mail
from django.conf import settings
from django.http import HttpResponse, HttpResponseRedirect

def home(request):
    return render(request, 'homeApp/home.html')

def contact(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '')
        email = request.POST.get('email', '')
        mensaje = request.POST.get('mensaje', '')
        
        # Envía el correo electrónico (sin destinatario por ahora)
        send_mail(
            'Mensaje de contacto',
            f'Nombre: {nombre}\nCorreo electrónico: {email}\nMensaje: {mensaje}',
            settings.EMAIL_HOST_USER,  # Remitente
            [],  # Sin destinatario (correo no se enviará)
        )
        return HttpResponseRedirect('/gracias/')  # Redirige a la página de agradecimiento
    return render(request, 'homeApp/contacto.html')

def gracias(request):
    return render(request, 'homeApp/gracias.html')

def aplicaciones(request):
    return render(request, 'homeApp/aplicaciones.html')